from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import *

def index(request):
    return render(request, "index.html")

def register(request):
    print("*"* 40)
    print(request.POST)
    Validationerrors = Registration.objects.registerValidator(request.POST)
    if len(Validationerrors)> 0:
        for key, value in Validationerrors.items():
            messages.error(request, value)
        return redirect("/")
    
    newUser = Registration.objects.create(first_name= request.POST['fname'], last_name= request.POST['lname'], email= request.POST['email'], password= request.POST['pw'])
    request.session['loggedInId'] = newUser.id   
    return redirect("/success")

def success(request):
    if "loggedInId" not in request.session:
        return redirect("/")
    loggedInUser = Registration.objects.get(id=request.session['loggedInId'])
    context = {
        'loggedInUser' : loggedInUser
    }
    return render(request, "success.html", context)

def login(request):
    print(request.POST)
    Validationerrors = Registration.objects.login_validator(request.POST)
    if len(Validationerrors) > 0:
        for key, value in Validationerrors.items():
            messages.error(request, value)
        return redirect("/")
    print(Validationerrors)
    emailFilter = Registration.objects.filter(email = request.POST['email'])
    request.session['loggedInId'] = emailFilter[0].id
    return redirect("/success")

def logout(request):
    request.session.clear()
    return redirect("/")