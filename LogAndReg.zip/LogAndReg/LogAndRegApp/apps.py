from django.apps import AppConfig


class LogandregappConfig(AppConfig):
    name = 'LogAndRegApp'
