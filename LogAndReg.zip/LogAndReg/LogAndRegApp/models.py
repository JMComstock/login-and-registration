from django.db import models
import re

class RegistrationManager(models.Manager):
    def registerValidator(self, postData):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        emailFilter = Registration.objects.filter(email = postData['email'])
        if len(postData['fname']) < 2:
            errors["fnamereq"] = "First name must be at least 2 characters"
        if len(postData["lname"]) < 2:
            errors["lnamereq"] = "Last name must be at least 2 characters"
        if len(postData["email"]) == 0:
            errors["emailreq"] = "Email is required"
        elif not EMAIL_REGEX.match(postData['email']):           
            errors['email'] = "Invalid email address! Use a vaild email format"
        if len(emailFilter)>0:
            errors['emailtaken'] = "This email is already registered, try a different email"
        if len(postData["pw"]) < 8:
            errors["pwreq"] = "Password must be at least 8 characters"
        if postData["pw"] != postData["cpw"]:
            errors["cpwmatch"] = "Confirm password must match Password"
        return errors

    def login_validator(self, postData):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        emailFilter = Registration.objects.filter(email = postData['email'])
        if len(postData['email']) == 0 :
            errors['emailreq'] = "email address is required"
        elif not EMAIL_REGEX.match(postData['email']):
            errors['emialpottern'] = "Must be a valid emial format"
        elif len(emailFilter) == 0:
            errors['noemailfound'] = "Email not found. Please register to login"
        else:
            print("email id found!")
            if emailFilter[0].password != postData['pw']:
                errors['passwordmatch'] = "Incorrect password"

        return errors
        

class Registration(models.Model):
    first_name = models.CharField(max_length=255) 
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = RegistrationManager()

class Login(models.Model):
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
